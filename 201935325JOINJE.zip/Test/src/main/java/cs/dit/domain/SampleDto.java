package cs.dit.domain;

import lombok.Data;

@Data
public class SampleDto {
	private String name;
	private int age;
}